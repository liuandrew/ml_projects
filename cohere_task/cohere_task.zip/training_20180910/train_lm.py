import os
import numpy as np
import pandas as pd
import pickle
from tqdm import tqdm
import matplotlib.pyplot as plt
patient_df = pd.read_csv('patient_record_summary.csv')
patient_df = patient_df.fillna('')
lines = list(patient_df['chief_complaint'].str.lower() + ' \n ' + patient_df['present_history'].str.lower())

# save to txt file to use with transformers dataset
file =  open('chief_history.txt', 'w')
for line in texts:
    file.write(line + '\n')
file.close()
# Update new tokens from text into bert model
from tokenizers import Tokenizer
from tokenizers.models import WordLevel
from tokenizers.trainers import WordLevelTrainer
from tokenizers.pre_tokenizers import Whitespace
import torch

# Ask a word level tokenizer to find word tokens from the dataset
vocab_finder = Tokenizer(WordLevel(unk_token='<unk>'))
trainer = WordLevelTrainer()
vocab_finder.pre_tokenizer = Whitespace()
vocab_finder.train_from_iterator(texts)
tokens = [key for key, value in vocab_finder.get_vocab().items()]

# Add new word tokens to bert-tiny model from HuggingFace
from transformers import AutoModelForMaskedLM, AutoTokenizer
model_name = 'prajjwal1/bert-tiny'

tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=True)
num_added_toks = tokenizer.add_tokens(tokens)

model = AutoModelForMaskedLM.from_pretrained(model_name)
model.resize_token_embeddings(len(tokenizer))


from transformers import LineByLineTextDataset

dataset = LineByLineTextDataset(
    tokenizer=tokenizer,
    file_path="chief_history.txt",
    block_size=512
)

from transformers import DataCollatorForLanguageModeling

data_collator = DataCollatorForLanguageModeling(
    tokenizer=tokenizer, mlm=True, mlm_probability=0.15
)

from transformers import Trainer, TrainingArguments

training_args = TrainingArguments(
    output_dir="./text_model",
    overwrite_output_dir=True,
    num_train_epochs=20,
    per_gpu_train_batch_size=16,
    save_steps=50,
    save_total_limit=2,
    prediction_loss_only=True,
    report_to=None
)

trainer = Trainer(
    model=model,
    args=training_args,
    data_collator=data_collator,
    train_dataset=dataset,
)

trainer.train()

tokenizer.save_pretrained('text_tokenizer')
model.save_pretrained('text_model')

